import os
import uuid
from datetime import datetime, timezone

from flask import Flask, jsonify, request

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024  # This API only accepts a small form payload.


def clean_text(value, max_length):
    if not isinstance(value, str):
        return ""
    return value.strip()[:max_length]


@app.get("/health")
def health():
    return jsonify(status="ok", service="backend"), 200


@app.post("/api/submit")
def submit_form():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify(error="Expected a JSON object."), 400

    name = clean_text(payload.get("name"), 100)
    email = clean_text(payload.get("email"), 254)
    message = clean_text(payload.get("message"), 1000)
    if not name or not email or not message:
        return jsonify(error="name, email, and message are all required."), 400
    if "@" not in email or email.startswith("@") or email.endswith("@"):
        return jsonify(error="Please provide a valid email address."), 400

    # This demo validates and returns the submission; it does not save personal data.
    return jsonify(
        message="Form submitted successfully!",
        service="Flask backend",
        submission_id=str(uuid.uuid4()),
        processed_at=datetime.now(timezone.utc).isoformat(),
        data={"name": name, "email": email, "message": message},
    ), 200


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify(error="Request body is too large."), 413


@app.errorhandler(404)
def not_found(_error):
    return jsonify(error="Endpoint not found."), 404


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
