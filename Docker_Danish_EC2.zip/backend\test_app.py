import unittest
from app import app


class BackendApiTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_health(self):
        response = self.client.get('/health')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()['service'], 'backend')

    def test_submit_valid_form(self):
        response = self.client.post('/api/submit', json={
            'name': 'Danish', 'email': 'danish@example.com', 'message': 'Docker test'
        })
        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertEqual(body['data']['name'], 'Danish')
        self.assertEqual(body['service'], 'Flask backend')
        self.assertTrue(body['submission_id'])

    def test_submit_rejects_missing_fields(self):
        response = self.client.post('/api/submit', json={'name': 'Danish'})
        self.assertEqual(response.status_code, 400)

    def test_submit_rejects_invalid_email(self):
        response = self.client.post('/api/submit', json={
            'name': 'Danish', 'email': 'not-an-email', 'message': 'Test'
        })
        self.assertEqual(response.status_code, 400)

    def test_submit_requires_json_object(self):
        response = self.client.post('/api/submit', data='not json', content_type='text/plain')
        self.assertEqual(response.status_code, 400)


if __name__ == '__main__':
    unittest.main()
