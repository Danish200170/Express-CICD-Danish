# Docker Full-Stack Application - Assignment Documentation

**Student:** Danish Qureshi  
**Assignment:** DevOps - Docker and Docker Compose  
**Project:** Express frontend + Flask API  
**Date:** 18 October 2026

> **Screenshot notice:** Capture genuine screenshots from your own machine while following this guide and place them in `docs/screenshots/`. The current creation workspace has no Docker CLI or Docker daemon, and no Docker Hub/GitHub publishing session. This document therefore includes clear screenshot placeholders/checkpoints rather than fabricated terminal images or claims of successful publishing.

## 1. Objective

The goal is to containerize a full-stack web application with two services: a Node.js/Express frontend and a Python/Flask backend. Docker Compose connects the services through a private bridge network. The frontend serves a form, posts the submitted data to the Flask API, and displays the backend's response.

## 2. Application architecture

- **Frontend:** Node.js 22, Express, EJS templates and Axios; published on host port `3000`.
- **Backend:** Python 3.12, Flask and Gunicorn; listens on container port `5000` and is intentionally not published directly to the host.
- **Service discovery:** Compose's internal DNS name `backend` means the frontend calls `http://backend:5000`.
- **Networking:** Both services share the `app-network` bridge network.
- **Health checks:** `/health` endpoints and Docker health checks verify each service.
- **Submission behavior:** The Flask endpoint validates form fields and responds with JSON. The demo does not persist the submitted data.

### Request flow

1. The user opens `http://localhost:3000` in a browser.
2. Express renders the EJS form.
3. On submission, Express validates that the form fields are present and sends a JSON `POST` request to `http://backend:5000/api/submit`.
4. Flask validates the incoming payload and returns a JSON response.
5. Express renders the success response in the browser.

## 3. Project structure

```text
Docker_Danish/
├── backend/
│   ├── app.py
│   ├── test_app.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .dockerignore
├── frontend/
│   ├── public/styles.css
│   ├── views/index.ejs
│   ├── server.js
│   ├── package.json
│   ├── Dockerfile
│   └── .dockerignore
├── docs/
│   ├── Documentation.docx
│   ├── Documentation.md
│   └── screenshots/
├── compose.yaml
├── .env.example
├── .gitignore
├── .dockerignore
└── README.md
```

## 4. Docker configuration

### Frontend Dockerfile

The frontend uses the official Node.js Alpine image, installs production dependencies, copies the server and view assets, runs as the non-root `node` user, exposes port `3000`, and defines a health check. Dependencies are declared in `package.json`; the Dockerfile installs them during the image build.

### Backend Dockerfile

The backend uses the Python slim image, installs the pinned dependencies, creates a non-root application user, exposes port `5000`, and runs Flask through the production-oriented Gunicorn server.

### Compose configuration

`compose.yaml` builds both images from their respective folders and names them using `DOCKERHUB_USERNAME`. It creates a shared bridge network, waits for the backend health check before starting the frontend, publishes only frontend port `3000`, and configures restart behavior.

### Ignore files

`.gitignore` excludes `node_modules`, Python bytecode and virtual environments, editor settings, logs, environment secrets, and build output. `.dockerignore` reduces the build context by excluding Git/editor metadata, local dependencies, secrets, and caches.

## 5. Run the project locally

Prerequisites: Docker Desktop or Docker Engine plus the Docker Compose plugin. Start the Docker service first.

From the project root:

```bash
cp .env.example .env
# Edit .env and set DOCKERHUB_USERNAME to your Docker Hub username.
docker compose config
docker compose up --build -d
docker compose ps
docker compose logs --tail=100
```

On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp` if needed. If you are using local builds only, setting `.env` still keeps the Compose image names consistent.

Open `http://localhost:3000`. Complete the Full name, Email address, and Message fields and click **Send to Flask API**. A successful request displays `Form submitted successfully!`, the `Flask backend` service label, a generated submission ID, and the form data returned by Flask.

Check health endpoints:

```bash
curl http://localhost:3000/health
docker compose exec backend python -c "import urllib.request; print(urllib.request.urlopen('http://localhost:5000/health').read().decode())"
```

Stop and remove the containers and network:

```bash
docker compose down
```

## 6. Test backend validation

The Flask API returns HTTP 400 for a missing field, non-JSON request, or malformed email input. A normal form returns HTTP 200 and JSON containing the service name, submission ID, timestamp, and data.

Optional unit tests can be run in a local Python virtual environment after installing `backend/requirements.txt`:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
cd backend
python -m unittest -v
cd ..
```

## 7. Build and publish images to Docker Hub

1. Sign in to Docker Hub and note your exact username.
2. In a terminal, run the commands below, replacing `YOUR_DOCKERHUB_USERNAME` with your username.
3. Authenticate interactively; never include the password or access token in a file or screenshot.

```bash
docker login --username YOUR_DOCKERHUB_USERNAME
docker build -t YOUR_DOCKERHUB_USERNAME/docker-assignment-backend:1.0 ./backend
docker build -t YOUR_DOCKERHUB_USERNAME/docker-assignment-frontend:1.0 ./frontend
docker images
docker push YOUR_DOCKERHUB_USERNAME/docker-assignment-backend:1.0
docker push YOUR_DOCKERHUB_USERNAME/docker-assignment-frontend:1.0
```

After pushing, open Docker Hub and confirm that both repositories and the `1.0` tags appear. Record both repository URLs below.

- Backend image: `https://hub.docker.com/r/YOUR_DOCKERHUB_USERNAME/docker-assignment-backend`
- Frontend image: `https://hub.docker.com/r/YOUR_DOCKERHUB_USERNAME/docker-assignment-frontend`

## 8. Push code to GitHub

Create a new repository named `Docker_Danish` in your GitHub account, preferably empty. In the project root run:

```bash
git init
git branch -M main
git add .
git status
git commit -m "Add Dockerized Express and Flask application"
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/Docker_Danish.git
git push -u origin main
```

Replace `YOUR_GITHUB_USERNAME` with the owner of the repository. Verify the repository URL and that all project source files are visible on GitHub. For HTTPS, GitHub requires a credential helper or a personal access token rather than the account password; SSH is another option. Do not store credentials in this project.

- **GitHub repository link:** `https://github.com/YOUR_GITHUB_USERNAME/Docker_Danish`

## 9. Screenshot evidence (required)

Use the Windows Snipping Tool (`Win + Shift + S`) or your operating system's screenshot feature. Capture the actual application output. Save PNG files in `docs/screenshots/` and insert them into this document in the matching sections below. Crop carefully and ensure no passwords, tokens, email credentials, or unrelated private information are visible.

### Evidence 1 - Docker Compose startup

**Capture:** terminal displaying the successful output from `docker compose up --build -d`.  
**Suggested filename:** `01-compose-build.png`  
**Explanation:** This demonstrates that Docker successfully built the frontend and backend images and started the services.

**Insert screenshot here.**

### Evidence 2 - Service and health status

**Capture:** output of `docker compose ps`, showing frontend and backend running/healthy.  
**Suggested filename:** `02-compose-ps.png`  
**Explanation:** This verifies that both services started and their health checks passed.

**Insert screenshot here.**

### Evidence 3 - Frontend form

**Capture:** browser at `http://localhost:3000` with the form visible. Sample data may be filled in but should not be sensitive.  
**Suggested filename:** `03-frontend-form.png`  
**Explanation:** This verifies the Express frontend renders the requested form.

**Insert screenshot here.**

### Evidence 4 - Successful form submission

**Capture:** browser showing the success message, Flask backend label, and returned submission details.  
**Suggested filename:** `04-form-success.png`  
**Explanation:** This verifies the frontend-to-backend request and response cycle.

**Insert screenshot here.**

### Evidence 5 - Locally built images

**Capture:** `docker images` output showing both `docker-assignment-frontend:1.0` and `docker-assignment-backend:1.0` under your Docker Hub username.  
**Suggested filename:** `05-docker-images.png`  
**Explanation:** This verifies the two expected image tags exist locally.

**Insert screenshot here.**

### Evidence 6 - Docker Hub repositories

**Capture:** Docker Hub page listing both pushed image repositories and the `1.0` tags.  
**Suggested filename:** `06-dockerhub.png`  
**Explanation:** This verifies images were published to the registry.

**Insert screenshot here.**

### Evidence 7 - GitHub code repository

**Capture:** the GitHub repository main page showing the code folder structure and README.  
**Suggested filename:** `07-github.png`  
**Explanation:** This verifies the complete source code was pushed to GitHub.

**Insert screenshot here.**

## 10. Submission checklist

- [ ] All source code and Docker configuration are inside `Docker_Danish/`.
- [ ] Both containers start successfully with Docker Compose.
- [ ] The form submits and shows the response from Flask.
- [ ] Both Docker images are pushed to Docker Hub and their URLs are recorded.
- [ ] All project code is pushed to GitHub and the repository link is recorded.
- [ ] Genuine screenshots are inserted into this document and copied to `docs/screenshots/`.
- [ ] `Documentation.docx` is saved inside the project folder.
- [ ] The complete folder is compressed as `Docker_Danish.zip` and that ZIP alone is uploaded to the submission portal.

**Important:** Do not submit with screenshot placeholders remaining. Capture and insert the real evidence after running the steps on your machine.
