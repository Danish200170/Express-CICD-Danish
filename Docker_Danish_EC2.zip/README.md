# Docker Full-Stack Assignment - Danish

A small full-stack form application for the DevOps Docker assignment. The Node.js/Express frontend renders a form and forwards its submission to a Python Flask API. Docker Compose puts both services on a private bridge network.

## Project structure

```text
Docker_Danish/
├── backend/
│   ├── app.py
│   ├── test_app.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .dockerignore
├── frontend/
│   ├── public/styles.css
│   ├── views/index.ejs
│   ├── server.js
│   ├── package.json
│   ├── Dockerfile
│   └── .dockerignore
├── docs/Documentation.docx
├── compose.yaml
├── .env.example
├── .gitignore
└── README.md
```

## Requirements

Install Docker Desktop (Windows/macOS) or Docker Engine and the Docker Compose plugin (Linux). Start Docker before running the commands below. For the publish steps, create accounts on GitHub and Docker Hub.

## Run locally with Docker Compose

1. Open a terminal in the project root.
2. Copy `.env.example` to `.env` and replace `your-dockerhub-username` with your Docker Hub username. (The app can also build locally; the variable controls image tags.)
3. Start both containers:

   ```bash
   docker compose up --build -d
   ```

4. Check status and logs:

   ```bash
   docker compose ps
   docker compose logs --tail=100
   ```

5. Visit `http://localhost:3000`, enter sample name/email/message, and submit. The success message should say `Flask backend`.
6. Check the health endpoints:

   ```bash
   curl http://localhost:3000/health
   # Backend is intentionally not published to the host; test it inside its service:
   docker compose exec backend python -c "import urllib.request; print(urllib.request.urlopen('http://localhost:5000/health').read().decode())"
   ```

Stop the services with `docker compose down`.

## Optional backend unit tests

From the project root, create a temporary virtual environment and run:

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
cd backend
python -m unittest -v
cd ..
```

## Docker Hub: build, tag, push

Replace `DOCKERHUB_USERNAME` below with your Docker Hub username. Login interactively so Docker handles the credential securely; do not write a password or access token into source code.

```bash
docker login --username YOUR_DOCKERHUB_USERNAME
docker build -t YOUR_DOCKERHUB_USERNAME/docker-assignment-backend:1.0 ./backend
docker build -t YOUR_DOCKERHUB_USERNAME/docker-assignment-frontend:1.0 ./frontend
docker push YOUR_DOCKERHUB_USERNAME/docker-assignment-backend:1.0
docker push YOUR_DOCKERHUB_USERNAME/docker-assignment-frontend:1.0
```

For Compose to use the published images on another machine, update `.env` with your username, then run `docker compose pull && docker compose up -d`. The compose file has both `build` and `image` configured, so local development can use `--build` and registry publishing can use the same image names.

## GitHub: create repository and push code

Create an empty GitHub repository named `Docker_Danish` (do not initialize it with an extra README if you want to use the commands unchanged). Then run from this folder:

```bash
git init
git branch -M main
git add .
git status
git commit -m "Add Dockerized Express and Flask application"
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/Docker_Danish.git
git push -u origin main
```

Replace the URL with the actual repository URL. GitHub does not accept account passwords for Git-over-HTTPS; use Git Credential Manager or a personal access token when Git prompts, or use SSH. Never put a token in this project or screenshot it. If `origin` already exists, inspect with `git remote -v` and use `git remote set-url origin ...` rather than adding it a second time.

## Troubleshooting

- Port 3000 is in use: change the host side of the Compose mapping to `3001:3000` and browse `http://localhost:3001`.
- Frontend says backend is unreachable: run `docker compose ps` and `docker compose logs backend frontend`; ensure `BACKEND_URL` is `http://backend:5000` in Compose. Use the service name, not `localhost`.
- Images won't push: verify the Docker Hub username, run `docker login`, and confirm the two repositories exist or allow first push.
- GitHub push is denied: verify the repository owner/name and your write access; authenticate with Git Credential Manager, a token with appropriate repository access, or SSH.

## Screenshots checklist

Place genuine screenshots captured on your own machine into `docs/screenshots/` and update the documentation before final submission. Capture: (1) `docker compose build` or `up --build` successful output; (2) `docker compose ps` with both services healthy; (3) browser form before submission; (4) browser success response after submission; (5) `docker images` showing both tags; (6) successful Docker Hub repositories/tags; and (7) GitHub repository showing the uploaded project. Hide access tokens, credentials, private URLs, and personal data. Do not use mock screenshots as proof of execution.
